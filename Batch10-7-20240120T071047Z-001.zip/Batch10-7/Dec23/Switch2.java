package Dec23;
public class Switch2 {
    public static void main(String[] args) {
        char c='e';
        switch(c)
        {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
            case 'A':

            System.out.println("Vowels");
            break;
            
           
            default:
            System.out.println("Consonants");


        }
    }
    
}
