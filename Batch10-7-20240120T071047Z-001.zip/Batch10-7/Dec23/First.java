package Dec23;
import java.util.*;
class First
{
    public static void main(String[] args) {
       int a=5;
       int b=a+++1;
       System.out.println(a);
       System.out.println(b);
    }
}