package Dec23;
public class switchex4 {
    public static void main(String[] args) {
        switch(2/2+1)
        {
            case 1:
            System.out.println("First");
            break;
            case 2:
            System.out.println("Jeeva");
            break;
            case 3:
            System.out.println("Karthick");
            break;
            default:
            System.out.println("Invalid");
        }
    }
    
}
