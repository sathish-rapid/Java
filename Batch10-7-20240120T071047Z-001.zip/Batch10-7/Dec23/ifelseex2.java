package Dec23;
import java.util.*;
public class ifelseex2 {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number");
        int n=sc.nextInt();
        if (n%2==0)
        {
            System.out.println("Even");
        }
        else{
            System.out.println("ODD");
        }


        
    }
    
}
