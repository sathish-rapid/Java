package Dec24;

public class BreakStatement {
    public static void main(String[] args) {
        for(int i=1;i<=100;i++)
        {
            if(i==79)
            
                   break;

            
          
            System.out.println(i);
        }
    }
    
}
