package Dec24;

public class ContinueStatement {
    public static void main(String[] args) {
        for(int i=1;i<=100;i++)
        {
            if(i==79)
            
                   continue;

            
          
            System.out.println(i);
        }
    }
    
}
