package Dec24;

public class Whileex1 {
    public static void main(String[] args) {

        int a=1;
        while(a<=100)
        {
            System.out.println(a);
            a=a+1;
        }
    
}
    
}
