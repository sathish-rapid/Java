package Dec24;

public class Dowhileex1 {
    public static void main(String[] args) {
        
        int a=101;
        do
        {
            System.out.println(a);
            a=a+1;

        }while(a<=100);


    }
    
}
