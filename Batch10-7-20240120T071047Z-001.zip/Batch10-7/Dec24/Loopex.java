package Dec24;

public class Loopex {
    public static void main(String[] args) {
        int i;
        for( i=1;i<=100;i++);
        {
            System.out.println(i*i);
        }

    }
    
}
