package Jan07;


public class AbstractionTest {
    
}
