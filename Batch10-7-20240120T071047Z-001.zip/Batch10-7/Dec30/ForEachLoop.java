package Dec30;

public class ForEachLoop {
    public static void main(String[] args) {
        
        int a[]={10,203,40,60};
        // for(int i=0;i<a.length;i++)
        // {
        //     System.out.println(a[i]);
        // }

        for(int s:a)
        {
            System.out.println(s);
        }

    
    }
    
}
